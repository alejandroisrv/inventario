<p>¿Estás seguro que desea vaciar la venta?</p>
