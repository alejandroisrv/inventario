<?php
      setlocale(LC_MONETARY,"es_PE");

      $total=str_replace(',','.', $_GET['total']);
      ?>
  <div id="pay-invoice">
    <div class="card-body pt-0">
      <div class="card-title">
        <h3 class="text-center">Método de pago</h3>
      </div>
    <hr>

     <div class="form-group text-center">
      <ul class="list-inline">
        <li class="list-inline-item px-3 py-2"><i class="text-muted far fa-credit-card fa-2x d-block metodoPago" data-metodo='visa'></i>Visa</li>
        <li class="list-inline-item px-2 py-2"><i class="text-muted far fa-money-bill-alt fa-2x d-block metodoPago" data-metodo='efectivo'></i>Efectivo</li>
      </ul>
    </div>

    <div class="form-group text-center my-4 px-0 metodoCuadro" id='efectivo'>

        <button type="button" name="pagoCon" class="btn btn-light billete mx-1" data-billete="10">S/. 10</button>
        <button type="button" name="pagoCon" class="btn btn-light billete mx-1" data-billete="20">S/. 20</button>
        <button type="button" name="pagoCon" class="btn btn-light billete mx-1" data-billete="50">S/. 50</button>
        <button type="button" name="pagoCon" class="btn btn-light billete mx-1" data-billete="100">S/. 100</button>
        <div class="form-group text-center my-4" id='vueltoNegativo'>
          <label for="total">Otro monto: S/.</label> <input type="text" class="form-control d-inline col-3" id="vueltoNegativoMonto" name="pagoCon" value="" />
        </div>
    </div>

    <div class="form-group text-center my-2">
      <label for="total">Total a pagar: <?php echo money_format('%(#10n',$total) ?>
      </label>
      <input type="hidden" name="total" value="<?php echo $total ?>">
      <input type="hidden" name="metodoPago" value="" id="pagoMetodo">
      <p class="col-6 my-4 d-inline" id="vuelto"></p>
    </div>
      <button id="payment-button" disabled="true" type="submit" class="btn btn-lg btn-primary btn-block">

        <span id="payment-button-amount">Cobrar <?php echo money_format('%(#10n',$total)?></span>
        <span id="payment-button-sending" style="display:none;">Enviando...</span>
      </button>
    </div>
  </div>
  <script>
  var metodoPago;
  var denominacion;
  var vuelto;
  var total = <?php echo $total ?>;
  var billetes;
  var billeteAnterior
  $('#vueltoNegativo').hide();
  $('#vuelto').hide();
  function animacion(clase,otro){
      $('.'+clase).addClass('text-muted');
      $('.'+clase).addClass('btn-light');
      $('.'+clase).removeClass('btn-dark');
      $('.'+clase).css('font-size','1rem');
      $(otro).addClass('btn-dark');
      $(otro).removeClass('text-muted');
      $(otro).css('font-size','1.3rem');
  }
  $('.metodoCuadro').hide();
      $('.metodoPago').on('click', function(){
        addDisable();
        $('#pagoMetodo').val($(this).attr('data-metodo'));
        $('.metodoPago').addClass("text-muted");
        $('.metodoPago').css('font-size','2em');
        $(this).removeClass('text-muted');
        $(this).css('font-size','3em');
        switch ($(this).attr('data-metodo')) {
          case 'efectivo':
          $('#vuelto').show();
          $('.metodoCuadro').fadeIn(300);
          $('.billete').on('click',function(){
             animacion('billete',this);
             function darVuelto(denominacion,total) {
              vuelto = denominacion-total;
              if(vuelto){
                $('#vuelto').text('Su vuelto S/. '+ vuelto.toFixed(2));
              }else{
                  $('#vuelto').text('');
              }

              if(vuelto>=0){
                  remDisable();
              }else{
                  addDisable();
              }
              return vuelto;
             }


              darVuelto($(this).attr('data-billete'),total);

              if(vuelto>=0){
                remDisable();
              }else{

                  $('#vueltoNegativo').show();
                  $('#vueltoNegativoMonto').focus();
                  $('#vueltoNegativoMonto').keyup(function() {
                        darVuelto($(this).val(),total);
                  });

                addDisable();
              }

          });
            break;
          case 'visa':
          $('#vuelto').text('');
          $('#vuelto').hide();
          $('.metodoCuadro').fadeOut(300);
          remDisable();
            break;
          case 'delivery':
              break;
          default:
          alert(metodoPago);
            break;
          }
        });

  </script>
