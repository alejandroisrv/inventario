//selling
function selling(producto,nombre){
  prepareModal("Vender " + nombre,"vender","core/sell.php");
  xhr_get("selling.php",modal,{'id':producto});
}
function updateSell(producto) {
  prepareModal("Modificar venta","Modificar","core/updateSell.php");
  xhr_get('modifySell.php',modal,{'id':producto});
}
function deleteSell(producto) {
  prepareModal("Elimnar venta","Eliminar","core/deleteSell.php");
  xhr_get('deleteSell.php',modal,{'id':producto});
  remDisable();
}
function deleteAllSell() {
  prepareModal("Vaciar venta","Vaciar","core/deleteAllSell.php");
  xhr_get('deleteAllSell.php',modal,null);
  remDisable();
}
function closeSell(total){
  prepareModal("","","core/closeSell.php");
  $('.modalclose').show();
  $('.modal-header').hide();
  $('.modal-footer').hide();
  xhr_get("closeSell.php",modal,{'total':total});
}

function addFavoritos(url,search){
  prepareModal("Lista de productos favoritos","Guardar","core/addFavoritos.php")
  xhr_get(url,modal,{'searchFavorito':search})
  remDisable();
}
function cajachica() {
  prepareModal("Registrar gastos","Registrar", "core/cajaChica.php");
  xhr_get('cajaChica.php',modal,null);

}
