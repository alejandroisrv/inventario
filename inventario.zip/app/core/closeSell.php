<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
include 'conexion.php';
$usuario=$_SESSION['usuario'];$modoVenta=$_COOKIE['modoventa'];
$total=$_POST['total'];$metodoPago=$_POST['metodoPago'];
$codigo=$_COOKIE['codigo'];
$queryCloseV=$con_pdo->query("SELECT * FROM ventas WHERE codigo='$codigo'");
if($queryCloseV->rowCount()==0){
 $sqlClose="INSERT INTO `ventas`( `codigo`, `fecha`, `hora`,`total`,`metodoPago`,`metodoVenta`,`usuario`)
          VALUES ('$codigo',now(),now(),'$total','$metodoPago','$modoVenta','$usuario')";
    $queryClose=$con_pdo->query($sqlClose);
    unset($_COOKIE['codigo']);
    setcookie('codigo','',time()-1000,'/','inv.donjuerguero.com');
    echo "OK";

}else{

    echo "ERROR";

}


?>
