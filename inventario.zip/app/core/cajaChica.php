<?php
include '../class/cajachica.php';
$caja=new cajachica();
$montos=$_POST['monto'];
$descripcion=$_POST['descripcion'];
  foreach( $montos as $key => $monto ) {
    if($monto>0){
      $result+=$caja->gastar($monto,$descripcion[$key]);
    }
  }


if($result>0){
  echo "OK";
}






 ?>
