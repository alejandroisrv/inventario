<?php include 'class/cajachica.php';
      setlocale(LC_MONETARY,"es_PE");
      $fecha=date('y')."-".date('m')."-".date('d');
      $cajachica = new cajachica();
      $gastos=$cajachica->getGastos($fecha);
      foreach ($gastos as $gasto) {
          $monto += $gasto['monto'];
      }?>

<p id="addGasto" class="d-inline col-6" style="font-size:0.75rem;margin-top:-10px"> <i class="far fa-plus-square fl-left mx-2"></i> Añadir otro gasto</p>
<p class="d-inline text-right col-6" style="font-size:0.75rem;margin-top:-10px"> <i class="fas fa-dollar-sign fl-right"></i> Gastos de hoy:<?php echo money_format('%(#10n',$monto ) ?> </p>
<p class="px-2 mx-3 mt-4">Coloca el monto y una pequeña descripcion para registrar el gasto </p>
<div class="addGastos col-12">
  <div class='form-row form-inline mt-2'>
    <input type='text' requerid name='monto[] ' class='form-control col-4 mx-2' placeholder='Monto'>
    <input type='text' requerid name='descripcion[] ' class='form-control col-6' placeholder='Descripcion'>
  </div>
</div>



<script>
remDisable()
$('#addGasto').on('click',function() {

  var cuadroGasto= "<div class='form-row form-inline mt-2'>"
                      +"<input type='text' requerid name='monto[] ' class='form-control col-4 mx-2' placeholder='Monto'>"
                      +"<input type='text' requerid name='descripcion[] ' class='form-control col-6' placeholder='Descripcion'>"
                  +"</div>"
$('.addGastos').append(cuadroGasto);
});

</script>
