<?php
include 'database.php';
/*
 Clase de ventas
 */
class ClassName extends conexion
{
  public $conexion;
  function __construct(argument)
  {
    $this->conexion=parent::__construct();
  }

  function getVenta($value='')
  {
    // code...
  }
}







 ?>
