<?php

include 'database.php';

class cajachica
{
  public $conexion;
  public $usuario;

  function __construct()
  {
      $this->conexion=new database();
  }

  public function gastar($monto,$descripcion) {
    $sql="INSERT INTO gastos (`monto`,`fecha`,`descripcion`,`hora`) VALUES ($monto, now(), '$descripcion',now())";
    $gastar=$this->conexion->prepare($sql);
    $gastar->execute();
    return $gastar->rowCount();
  }

  public function getGastos($fecha)
  {
    $sql="SELECT * FROM gastos WHERE fecha = '$fecha' ";
    $getMonto=$this->conexion->prepare($sql);
    $getMonto->execute();
    return $getMonto->fetchAll();
  }

  public function setMonto($monto)
  {
    $gastar=$this->conexion->query("UPDATE cajachica SET monto = $monto, fecha = now()");
    return $gastar->rowCount();
  }

  public function getMonto($monto)
  {
    $getMonto=$this->conexion->query("SELECT monto FROM cajachica");
    return $getMonto->fetchAll();

  }






}













?>
