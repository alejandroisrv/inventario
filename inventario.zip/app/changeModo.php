<?php
session_start();
if($_SESSION['usuario']!="admin"){
          $hora=date("G");
      if(($hora>=21 && $hora<=23) || ($hora>=0 && $hora<=4) ):
          $noche=true;
      else:
          $noche=false;
      endif;
      
      if(($noche) && ($_GET['modoventa']=="delivery" || $_GET['modoventa']=="noche")){
          
        echo "OK";
          
      }else if((!$noche) && ($_GET['modoventa']=="delivery" || $_GET['modoventa']=="dia")){
                   setcookie('modoventa',$_GET['modoventa'],time()+ 14400 ,'/');
        echo "OK";
      }else{
          
          echo "ERROR";
      }
    
}else{
    
    setcookie('modoventa',$_GET['modoventa'],time()+ 14400 ,'/');
        echo "OK";
    
}

















?>